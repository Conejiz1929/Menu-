/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.caso1_1;

import javax.swing.JOptionPane;

/**
 *
 * @autor Conej
 */
public class Vehiculo {
    private String Marca = "";
    private String Modelo = "";
    private int Antiguedad = 0;
    private int anio = 0;

    // Constructor con parámetros
    public Vehiculo(String Marca, String Modelo, int Antiguedad, int anio) {
        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Antiguedad = Antiguedad;
        this.anio = anio;
    }

    // Constructor predeterminado sin excepciones
    public Vehiculo() {
        // Inicialización básica si es necesario
    }

    // Getters y Setters
    public String getMarca() {
        return Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public int getAntiguedad() {
        return Antiguedad;
    }
    
    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
    
    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public void setAntiguedad(int Antiguedad) {
        this.Antiguedad = Antiguedad;
    }
    
    // Métodos para pedir datos, calcular antigüedad y mostrar datos
    public void pedirDatos() {
        this.Marca = JOptionPane.showInputDialog(null, "Escriba la marca del vehiculo");
        this.Modelo = JOptionPane.showInputDialog(null, "Escriba el modelo del vehiculo");
        this.anio = Integer.parseInt(JOptionPane.showInputDialog(null, "Escriba el año del vehiculo"));
    }

    public void calcAntiguedad() {
        this.Antiguedad = 2024 - this.anio;
    }
    
    public void mostrarDatos() {
        JOptionPane.showMessageDialog(null,
                "La marca del vehiculo es: " + this.Marca + "\n"
                + "El modelo del vehiculo es: " + this.Modelo + "\n"
                + "La antiguedad del vehiculo es: " + this.Antiguedad + "\n"
                + "El año del vehiculo es: " + this.anio
        );
    }
}

