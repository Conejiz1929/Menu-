/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.caso1_1;

import javax.swing.JOptionPane;

/**
 *
 * @autor Conej
 */
public class Salario {
    private int precio_por_hora;
    private int horas_Laboradas;
    private int porcentaje_deducciones;
    private int SalarioNeto;

    public Salario(int precio_por_hora, int horas_Laboradas, int porcentaje_deducciones, int SalarioNeto) {
        this.precio_por_hora = precio_por_hora;
        this.horas_Laboradas = horas_Laboradas;
        this.porcentaje_deducciones = porcentaje_deducciones;
        this.SalarioNeto = SalarioNeto;
    }

    public Salario() {
        // Constructor vacío
    }

    public int getPrecio_por_hora() {
        return precio_por_hora;
    }

    public int getHoras_Laboradas() {
        return horas_Laboradas;
    }

    public int getPorcentaje_deducciones() {
        return porcentaje_deducciones;
    }

    public int getSalarioNeto() {
        return SalarioNeto;
    }

    public void setPrecio_por_hora(int precio_por_hora) {
        this.precio_por_hora = precio_por_hora;
    }

    public void setHoras_Laboradas(int horas_Laboradas) {
        this.horas_Laboradas = horas_Laboradas;
    }

    public void setPorcentaje_deducciones(int porcentaje_deducciones) {
        this.porcentaje_deducciones = porcentaje_deducciones;
    }

    public void setSalarioNeto(int SalarioNeto) {
        this.SalarioNeto = SalarioNeto;
    }

    public void TomarDatos() {
        this.precio_por_hora = Integer.parseInt(JOptionPane.showInputDialog("Digite su precio por hora"));
        this.horas_Laboradas = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite sus horas laboradas"));
        this.porcentaje_deducciones = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite su porcentaje de deducciones"));
    }

    public void calcular_salario_neto() {
        this.porcentaje_deducciones = this.porcentaje_deducciones / 100;
        this.SalarioNeto = this.precio_por_hora * this.horas_Laboradas * (1 - this.porcentaje_deducciones);
    }

    public void mostrarDatos() {
        JOptionPane.showMessageDialog(null, "Su salario neto es: " + this.SalarioNeto);
    }
}
