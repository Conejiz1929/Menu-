/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.caso1_1;

import javax.swing.JOptionPane;

/**
 *
 * @author Conej
 */
public class Caso1_1 {

    public static void main(String[] args) {
        while (true) {
            String menuprincipal = JOptionPane.showInputDialog(null, "Eliga una de las siguientes opciones\n"
                    + "[1] - Verificar la antigüedad de un vehículo\n"
                    + "[2] - Calcular el factorial de un número\n"
                    + "[3] - Calcular el salario neto de un empleado\n"
                    + "[4] - Calcular el IMC de una persona\n"
                    + "[5] - Salir del programa");

            switch (menuprincipal) {
                case "1":
                    // Antigüedad vehículo
                    ejercicio_1();
                    break;
                case "2":
                    // Factorial número
                    calcular_Factorial();
                    break;
                case "3":
                    // Salario neto
                    calcular_Salario();
                    break;
                case "4":
                    // IMC persona
                    calcular_imc_persona();
                    break;
                case "5":
                    // Salir del programa
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción incorrecta, ingrese una opción válida.");
            }
        }
    }

    public static void ejercicio_1() {
        Vehiculo vehiculo = new Vehiculo();
        vehiculo.pedirDatos();
        vehiculo.calcAntiguedad();
        vehiculo.mostrarDatos();
    }

    public static void calcular_Factorial(){
        int factorial =Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el factorial"));
        int calcfacto = 1;
        
        if  (factorial >= 0){
            for (int i = 1; i <= factorial ; i++) {
                 calcfacto *= i;
            }
            JOptionPane.showMessageDialog(null,"El factorial de: "+factorial+" es: "+calcfacto);
        }
        else {
            JOptionPane.showMessageDialog(null,"Numero no  es permitido");
        }
    }

    public static void calcular_Salario() {
        Salario salario = new Salario();
        salario.TomarDatos();
        salario.calcular_salario_neto();
        salario.mostrarDatos();
    }

    public static void calcular_imc_persona() {
        double estatura = Double.parseDouble(JOptionPane.showInputDialog("Digite su estatura en metros"));
        double peso = Double.parseDouble(JOptionPane.showInputDialog("Digite su peso en kilogramos"));

        double imc = peso / (estatura * estatura);

        JOptionPane.showMessageDialog(null, "Su IMC es: " + imc);

        if (imc < 18.5) {
            JOptionPane.showMessageDialog(null, "Peso inferior al normal");
        } else if (imc >= 18.5 && imc < 24.9) {
            JOptionPane.showMessageDialog(null, "Peso normal");
        } else if (imc >= 25 && imc < 29.9) {
            JOptionPane.showMessageDialog(null, "Peso superior al normal");
        } else {
            JOptionPane.showMessageDialog(null, "Obesidad");
        }
    }
}
